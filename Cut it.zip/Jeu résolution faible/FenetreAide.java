import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Font;

	public class FenetreAide extends JFrame implements ActionListener{
		//fenetre qui s'affiche lorsque le joueur demande de l'aide
		JLabel Aide;
		JLabel Fond;
		JPanel Pannel;
		JButton Menu;
		
		public FenetreAide(){
		
		this.setTitle("Aide");
		this.setSize(849,790);
		this.setLocation(0,0);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Font myFont = new Font ("Arial",Font.BOLD,30);
		
		Menu = new JButton("Menu");
		Menu.setBounds(0,640,200,100);
		Menu.setBackground(new Color(50,140,60));
		Menu.setForeground(Color.white);
		Menu.addActionListener(this);
		Menu.setFont(myFont); 
		Menu.setLayout(null);
		this.add(Menu);
		
		Fond = new JLabel(new ImageIcon("Fondaide.png"));
		Fond.setBounds(0,0,849,790);
		
		this.add(Fond);
		this.setVisible(true);
	}
	public void actionPerformed (ActionEvent e){
		if(e.getSource()==Menu){
			this.dispose();
		}
			
	}
	
}
