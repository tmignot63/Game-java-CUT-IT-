import java.util.ArrayList; 
import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;
import java.awt.Graphics;
import javax.swing.Timer;

public class Boule extends Objet{
	
	public int taille;
	//coefficient de frottement 
	public double resistance;
	//vitesses
	public double vy;
	public double vx;
	//acceleration
	public double ay;
	public double ax;

	public double x_a;//ancien x
	public double y_a;//ancien y

	ArrayList <Pendule> pendules;

	public Boule(double x,double y, int t, ArrayList <Pendule> pendules){
		
		super(x,y);
		taille=t;
		this.pendules=pendules;

		resistance=0.009;
		
		vy=0;
		vx=0;

		ay=1;
		ax=0;
	}

	public void bouge(Obstacle o) {
		//methode permettant de detecter les collisions avec un obstacle
		int rayon= (int) (taille/2);
		double choc= o.choc;

		if (y - rayon <=o.y+o.ty && y+rayon>=(o.y+o.ty/2) && x+rayon<=o.x+o.tx &&x-rayon>=o.x && vy<0) {

			 y = o.y+o.ty+rayon;
			 vy =-vy;
			 vy = vy * choc; // coefficient de friction avec l'obstacle appliqué
			 
	 	}

	 	else{

			if (y + rayon >=o.y && y-rayon<=(o.y+o.ty/2) && x+rayon<=o.x+o.tx &&x-rayon>=o.x && vy>0 ) {

			 // collision en haut de l'obstacle
			
				 y = o.y-taille/2;
				 vy =-vy;
				 vy = vy * choc; 

		 	}

		 }


	 	if (x + rayon >=o.x && x-rayon<=(o.x+o.tx/2) && y+rayon<=o.y+o.ty &&y-rayon>=o.y && vx>0  ){

		 // collision a gauche de l'obstacle
	 		
			 x = o.x-taille/2;
			 vx =-vx;
			 vx = vx * choc; 
		
	 	}

	 	else{

		 	if (x - rayon <=o.x+o.tx && x+rayon>=(o.x+o.tx/2) && y+rayon<=o.y+o.ty &&y-rayon>=o.y &&vx<0 ) {
				//collision a droite de l'obstacle
				 x = o.x+o.tx+rayon;
				 vx =-vx;
				 vx = vx * choc; 
		 	}
	 	}

	}
		
	 public void bouge() {

	 	//modelisation de la chute libre
	 	x_a=x;
	 	y_a=y;//actualisation des anciennes coordonnes

	 	//Euler explicite
		ay=g-resistance*Math.sqrt(vy*vy);
		ax=resistance*Math.sqrt(vx*vx);
		
		vy=vy+ay;
		
		if(vx==0){

			ax=0;
		}

		else{

			if(vx>0){
				vx=vx-ax;

			
				if(vx<0){
					vx=0;
				}

			}
			else{
				
				vx=vx+ax;

				if(vx>0){
					vx=0;
				}
			}

		}

		y=y+vy;
		x=x+vx;

	 }

	 public void bouge_pendule(Obstacle o) {
	 	//gere les collisions avec l'obstacle lorsque la boule est encore attachee
	 	int rayon= (int) (taille/2);

	 	double vy=this.pendules.get(0).vitesse_y();

		double vx=this.pendules.get(0).vitesse_x();

	 	if (y - rayon <=o.y+o.ty && y+rayon>=(o.y+o.ty/2) && x+rayon<=o.x+o.tx &&x-rayon>=o.x && vy<0) {

		 // collision en bas de l'obstacle
	 		this.pendules.get(0).teta-=this.pendules.get(0).teta2;
			this.pendules.get(0).teta2*=-0.9;
			
	 	}

	 	else{

			if (y + rayon >=o.y && y-rayon<=(o.y+o.ty/2) && x+rayon<=o.x+o.tx &&x-rayon>=o.x && vy>0 ) {

			 // collision au dessus 
				this.pendules.get(0).teta-=this.pendules.get(0).teta2;
				this.pendules.get(0).teta2*=-0.9;
				
		 	}
		 	else{

		 		if (x + rayon >=o.x && x-rayon<=(o.x+o.tx/2) && y+rayon<=o.y+o.ty &&y-rayon>=o.y && vx>0  ){
		 	//collision a gauche
		 	this.pendules.get(0).teta-=this.pendules.get(0).teta2;
			this.pendules.get(0).teta2*=-0.9;

	 	}

	 	else{

		 	if (x - rayon <=o.x+o.tx && x+rayon>=(o.x+o.tx/2) && y+rayon<=o.y+o.ty &&y-rayon>=o.y &&vx<0 ) {
		 		//collision a droite
				this.pendules.get(0).teta-=this.pendules.get(0).teta2;
				this.pendules.get(0).teta2*=-0.9; 
				
		 			}
	 			}

			}
		}

	}
			
}