import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;
import java.awt.Graphics;
import javax.swing.Timer;
import java.util.ArrayList; 
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.Point;
import java.awt.Dimension;
import java.awt.*;

public  class FenetreNiveau extends JFrame implements ActionListener,MouseMotionListener,MouseListener,KeyListener{
	//initialisation des attributs

	
	double WIDTH = 1000;
	double HEIGHT = 1000;

	//declaration des variables permettant de definir chaque niveau

	Timer timer ;
	Boule boule;
	ArrayList <Pendule> pendules;
	ArrayList <Obstacle> obstacles;
	ArrayList <ObstacleBouge> obstaclesB;
	ArrayList <PenduleSP> pendulesSP;
	ArrayList <Curseur> curseurs;
	double ancienx;
	double ancieny;
	ImageIcon OmNom1;
	ImageIcon OmNomMiam;
	ImageIcon OmNomBouche;
	ImageIcon OmNomTriste;
	ImageIcon Fond;
	ImageIcon Bonbon;
	ImageIcon Star;
	Arrive arrive;
	ImageIcon couteau;
	ArrayList <Etoile> ListeEtoiles;
	int num;
	
	BufferedImage monBuf;
	BufferedImage monBuf2;
	ParametresNiveau ParametresNiveauCourant;

	//declaration de toutes les variables de condition necessaires

	boolean manger=false;
	boolean cdt2=false;
	boolean detection=false;

	int compteur=0;
	boolean cut=true;
	Pendule ptemp=null;

	//coordonnes des clics

	double xclic;
	double yclic;

	//variables permettant de gerer l'inertie de la boule avec le curseur

	double vx_a=0;
	double vx;
	double ax=0;

	double vy_a=0;
	double vy;
	double ay=0;

	public FenetreNiveau(ParametresNiveau ParametresNiveau1){     //ArrayList <Obstacle> OBSTACLES, ArrayList <Pendule> PENDULES, Boule BOULE, ArrayList <Etoile> LISTEETOILES, Arrive ARRIVE) {
		super(" Cut it  ");
		ParametresNiveauCourant=ParametresNiveau1;

		this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

		Dimension ecran = Toolkit.getDefaultToolkit().getScreenSize(); 

		double h = ecran.getSize().height*9.0/10.0;
		
		WIDTH=h;
		HEIGHT=h;
		
		this.setSize ((int)(h), (int)(h));

		setLayout(null);
		addMouseMotionListener(this);
		addMouseListener(this);
		addKeyListener(this);

		this.obstacles=ParametresNiveau1.obstacles;
		this.obstaclesB=ParametresNiveau1.obstaclesB;
		this.boule=ParametresNiveau1.boule;
		this.pendules=ParametresNiveau1.pendules;
		this.arrive = ParametresNiveau1.arrive;
		this.ListeEtoiles = ParametresNiveau1.ListeEtoiles;
		this.num = ParametresNiveau1.numero;
		this.pendulesSP=ParametresNiveau1.pendulesSP;
		this.curseurs=ParametresNiveau1.curseurs;
		
		monBuf = new BufferedImage((int)WIDTH,(int)HEIGHT,BufferedImage.TYPE_INT_RGB);
		monBuf2 = new BufferedImage((int)WIDTH,(int)HEIGHT,BufferedImage.TYPE_INT_RGB);
		
		OmNom1 = new ImageIcon("OmNom1.png");
		OmNomMiam = new ImageIcon("OmNomMiam.gif");
		OmNomBouche = new ImageIcon("OmNomBouche.png");
		OmNomTriste = new ImageIcon("OmNomTriste.gif");
		Fond = new ImageIcon(new ImageIcon("Fond.jpg").getImage().getScaledInstance((int)WIDTH,(int)HEIGHT,Image.SCALE_DEFAULT));
		Bonbon = new ImageIcon("bonbon.png");
		Star = new ImageIcon("Star2.png");
		couteau = new ImageIcon("couteau.png");
		
		timer =new Timer(10,this);

		timer.start();

		this.setVisible(true);
		

	}

	public void dessine_lourd(Graphics g){
		//methode qui permet de dessiner, afficher tous éléments sans le scintillement
		Fond.paintIcon(this, g, 0, 0);

		for(int j=0;j<=boule.pendules.size()-1;j++){

			boule.pendules.get(j).dessine(g);
		}

		for(int a=0;a<=pendulesSP.size()-1;a++){

			pendulesSP.get(a).dessine2(g);
		}


			for(int z=0; z<curseurs.size(); z++){

				curseurs.get(z).dessine(g);
			}
		

		for(int p=0;p<=obstacles.size()-1;p++){

			obstacles.get(p).icon.paintIcon(this, g, (int)obstacles.get(p).x, (int)obstacles.get(p).y);
			
		}

		for(int p=0;p<=obstaclesB.size()-1;p++){

			obstaclesB.get(p).icon.paintIcon(this, g, (int)obstaclesB.get(p).x, (int)obstaclesB.get(p).y);

		}


	if(boule.x < 0 || boule.x > WIDTH || boule.y < 0 || boule.y > HEIGHT ){
		//la boule est partie de l'ecran : perdu 
				OmNomTriste.paintIcon(this, g, arrive.x, arrive.y);
				FenetreResultat FenetreR = new FenetreResultat(false, ListeEtoiles.size(), num);
				this.dispose();
			}
			
		
			else{

						if(Math.pow(Math.pow(boule.x-arrive.x-110,2) + Math.pow(boule.y-arrive.y-110,2) , 0.5) < arrive.l){
							//la boule arrive dans la bouche 
							
					         	compteur+=1;
					         	
					         	OmNomMiam.paintIcon(this, g, arrive.x-20 , arrive.y-20);
      	 timer.stop();

         if(compteur==15){
			 //compteur pour gerer l'affichage de l'animation quand il mange la boule
			 //creation de la fenetre résultat
         	FenetreResultat FenetreR = new FenetreResultat(true, ListeEtoiles.size(), num);
			this.dispose();
			compteur=0;

         }

						}	
				else{

					if(Math.pow(Math.pow(boule.x-arrive.x-110,2) + Math.pow(boule.y-arrive.y-110,2) , 0.5) < arrive.d ){
					OmNomBouche.paintIcon(this, g, arrive.x, arrive.y);
					// animation de la boule qui approche du Omnom

				}

							else{
										if( Math.pow(Math.pow(boule.x-arrive.x-110,2) + Math.pow(boule.y-arrive.y-110,2) , 0.5) > arrive.d ){
										OmNom1.paintIcon(this, g, arrive.x, arrive.y);
										//affichage normal du Omnom
										}
							}
				}
			}

		for(int i=0; i<ListeEtoiles.size(); i++){
			Star.paintIcon(this, g, (int)ListeEtoiles.get(i).x - 25, (int)ListeEtoiles.get(i).y - 25);
		}

		if(timer.isRunning()){

			Bonbon.paintIcon(this, g, (int)boule.x - 20, (int)boule.y - 20);
		}

	}

	public void paint(Graphics g){
		
		dessine_lourd(monBuf.getGraphics()); 
		g.drawImage(monBuf,0,0,this); 
	
	}

	public void actionPerformed(ActionEvent e){

		for(int z=0;z<=curseurs.size()-1;z++){
			//permet de gerer l'inertie de la boule lors du deplacement d'un curseur
			if(curseurs.get(z).nouveaux!=curseurs.get(z).ancienx){
				//calcul de la vitesse instantanee du curseur
				vx=curseurs.get(z).nouveaux-curseurs.get(z).ancienx;
				//acceleration instantanee
				ax=vx-vx_a;
				//mise ajour des vitesses et de la position
				vx_a=vx;
				curseurs.get(z).ancienx=curseurs.get(z).nouveaux;

			}
			else{

				ax=0;
			}

			curseurs.get(z).pendule.a=ax;

			if(curseurs.get(z).nouveauy!=curseurs.get(z).ancieny ){
				//meme chose en y
				vy=curseurs.get(z).nouveauy-curseurs.get(z).ancieny;
				ay=vy-vy_a;
				vy_a=vy;
				curseurs.get(z).ancieny=curseurs.get(z).nouveauy;
				curseurs.get(z).pendule.a=ay;
			}
			else{

				ay=0;
			}

		}

		if(boule.pendules.size()==0){
			//cas de la chute libre
			
			for(int i=0;i<=pendulesSP.size()-1;i++){
				//recherche si la boule arrive dans une zone de detection d'un penduleSP
				PenduleSP p=pendulesSP.get(i);

				double l=Math.sqrt((p.x-boule.x)*(p.x-boule.x)+(p.y-boule.y)*(p.y-boule.y));
				if(l<=p.rayon_detection){
		
					PenduleF Pa;
					if(boule.x<p.x){
						 Pa=new PenduleF(Math.sqrt(boule.vx*boule.vx+boule.vy*boule.vy)/l,p.x,p.y,boule,p.k);
					}
					else{
						 Pa=new PenduleF(-Math.sqrt(boule.vx*boule.vx+boule.vy*boule.vy)/l,p.x,p.y,boule,p.k);
						
					}
					pendules.add(Pa);
					//on transforme le penduleSP en Pendule en l'ajoutant dans la liste Pendules
					
						for(int m=0;m<=curseurs.size()-1;m++){
							if(curseurs.get(m).pendule==p){

								curseurs.get(m).pendule=Pa;

							}
						}
						//suppression du pendule SP inutile
						pendulesSP.remove(i);
					
				}


				}
		}

        // on fait bouger les obstaclesBouge
		for(int m=0;m<=obstaclesB.size()-1;m++){
			obstaclesB.get(m).bouger();

		}

			if(boule.pendules.size()==1){
				//verification collisions avec obstacles avec boule accroche

				for(int m=0;m<=obstacles.size()-1;m++){
				boule.bouge_pendule(obstacles.get(m));

				}

				for(int m=0;m<=obstaclesB.size()-1;m++){
				boule.bouge_pendule(obstaclesB.get(m));

				}
				//mise a jour du pendule

			boule.pendules.get(0).simulate();

		}
	

		if(boule.pendules.size()==0){
			//mise a jour de la boule non accrochee

			boule.bouge();
			for(int p=0;p<=obstacles.size()-1;p++){

				boule.bouge(obstacles.get(p));
	
			}
			//collision avec obstacle

			for(int p=0;p<=obstaclesB.size()-1;p++){

		
				boule.bouge(obstaclesB.get(p));
	
				
			}

		}
		
		for(int i=0; i<ListeEtoiles.size(); i++){
			if(boule.x > ListeEtoiles.get(i).x - ListeEtoiles.get(i).d && boule.x < ListeEtoiles.get(i).x + ListeEtoiles.get(i).d && boule.y > ListeEtoiles.get(i).y - ListeEtoiles.get(i).d && boule.y < ListeEtoiles.get(i).y + ListeEtoiles.get(i).d){
				ListeEtoiles.remove(i);
			}
		}

		 Boule boule_poubelle2;
		 Pendule pendule_poubelle2;

		 if(cdt2==true && boule.pendules.size()==1){

		 	 for(int k=0;k<=pendules.size()-1;k++){
		 	 	
		 	 	boule_poubelle2=new Boule(xclic,yclic,0,pendules);
		 	 	pendule_poubelle2=new Pendule(0,pendules.get(k).x,pendules.get(k).y,boule_poubelle2);

		 	 	double teta_n=pendules.get(k).teta-pendule_poubelle2.teta;

		 	 	double teta_a=pendules.get(k).teta_a-pendule_poubelle2.teta;
		 	 	if(teta_a*teta_n<=0 && Math.sqrt((pendules.get(k).x-xclic)*(pendules.get(k).x-xclic)+(pendules.get(k).y-yclic)*(pendules.get(k).y-yclic))<=pendules.get(k).l){
		 	 		boule.vx=pendules.get(k).vitesse_x();
		 	 		boule.vy=pendules.get(k).vitesse_y();
		 	 		
		 	 		pendules.remove(k);	
		 	 	}
		 	}
		}
	 	
			repaint();
	}

	public void keyPressed(KeyEvent e){}

	public void keyReleased(KeyEvent e){

		int code=e.getKeyCode();
		//recommencer niveau avec touche espace

		if (code==KeyEvent.VK_SPACE){

			timer.stop();
			FenetreResultat FenetreR = new FenetreResultat(true, ListeEtoiles.size(), num);
			FenetreR.recommencer();
			this.dispose();

		}

		if (code==KeyEvent.VK_ENTER){
			
			this.dispose();

		}


		repaint();

	}
	
	public void mousePressed(MouseEvent e) {

		ancienx=e.getX();
		ancieny=e.getY();
		double x=ancienx;
		double y=ancieny;
		cdt2=true;
		xclic=ancienx;
		yclic=ancieny;

		//detection curseur a ajuster

		for(int k=0;k<=curseurs.size()-1;k++){
			if(Math.sqrt((x-curseurs.get(k).pendule.x)*(x-curseurs.get(k).pendule.x)+(y-curseurs.get(k).pendule.y)*(y-curseurs.get(k).pendule.y))<=8){
				cut=false;
				cdt2=false;
				ptemp=curseurs.get(k).pendule;	
			}

		}

	}
	
	public void mouseReleased(MouseEvent e) {
		//on remet les variables de vitesse et acceleration du curseur a 0 quand on le lache

		cut=true;ptemp=null;cdt2=false;ax=0;vx=0;vx_a=0;ay=0;vy=0;vy_a=0;}

	public void mouseDragged(MouseEvent e) {
		xclic=e.getX();
		yclic=e.getY();
		 double x;
		 double y;
		
		if (contains(e.getX(),e.getY())){

			x=e.getX();
	 		y=e.getY();

	 		if(cut==false){

	 		for(int k=0;k<=curseurs.size()-1;k++){
	 			if(ptemp==curseurs.get(k).pendule){
	 				if(pendules.size()==1){
						
						//deplacement curseur
	 					curseurs.get(k).deplacer(x,y,true);

	 				}
	 				else{

				curseurs.get(k).deplacer(x,y,false);
				}
			}
			
		}

		repaint();
	}

		else{
			
			//detection cut de la corde

		 Boule boule_poubelle;
		 Boule boule_poubelle2;

		 Pendule pendule_poubelle;
		 Pendule pendule_poubelle2;

		 	 for(int k=0;k<=pendules.size()-1;k++){

		 	 	if(pendules.get(k).x==boule.x){
		 	 		if((ancienx-boule.x)*(x-boule.x)<=0 && (((ancieny<=pendules.get(k).y && ancieny>=boule.y)||(ancieny>=pendules.get(k).y && ancieny<=boule.y))||(y<=pendules.get(k).y && y>=boule.y)||(y>=pendules.get(k).y && y<=boule.y)) ){
		 	 				boule.vx=pendules.get(k).vitesse_x();
		 	 				boule.vy=pendules.get(k).vitesse_y();
		 	 				pendules.remove(k);

		 	 		}

		 	 	}

		 	 	else{

		 	 	if( ((y<=pendules.get(k).y && y>=boule.y)||(y>=pendules.get(k).y && y<=boule.y)) || ((ancieny<=pendules.get(k).y && ancieny>=boule.y)||(ancieny>=pendules.get(k).y && ancieny<=boule.y))) {
		 	 	double copieteta=pendules.get(k).teta;
		 	 	
		 	 	boule_poubelle=new Boule(x,y,0,pendules);
		 	 	pendule_poubelle=new Pendule(0,pendules.get(k).x,pendules.get(k).y,boule_poubelle);
		 	 	pendule_poubelle.teta-=pendules.get(k).teta;

		 	 	 boule_poubelle2=new Boule(ancienx,ancieny,0,pendules);
		 	 	pendule_poubelle2=new Pendule(0,pendules.get(k).x,pendules.get(k).y,boule_poubelle2);
		 	 	pendule_poubelle2.teta-=pendules.get(k).teta;

		 	 	pendules.get(k).teta=0;

		 	 	if((pendule_poubelle.getX()-pendules.get(k).getX())*(pendule_poubelle2.getX()-pendules.get(k).getX())<=0){
		 	 	
		 	 		boule.vx=pendules.get(k).vitesse_x();
		 	 		boule.vy=pendules.get(k).vitesse_y();
		 	 		
		 	 		pendules.remove(k);

		 	 	}

		 	 	else{
		 	 	pendules.get(k).teta=copieteta;
							}

						}
					}

				}
			}
	ancienx=x;
	ancieny=y;
	 repaint();
	
		}

	}
	 
	public void mouseMoved(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void keyTyped(KeyEvent e){}
	public void mouseClicked(MouseEvent e) {}
}

