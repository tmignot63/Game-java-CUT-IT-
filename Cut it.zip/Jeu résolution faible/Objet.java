
public class Objet {
	
	public double x;
	public double y;
	public final int g;


  public Objet(double xo, double yo){
  x=xo;
  y=yo;
  g=1;
  
  }
	
} 
