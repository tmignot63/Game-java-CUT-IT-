import java.util.ArrayList; 
import javax.swing.*;
import java.awt.Toolkit;
import java.awt.Point;
import java.awt.Dimension;

public class Parametres{
	ArrayList <ParametresNiveau> ListeParametres;
	double h;
	
	public Parametres(){
		
		ImageIcon Plateforme = new ImageIcon("Plateforme.png");
		ImageIcon Rocher = new ImageIcon("Rocher.jpg");
		ImageIcon Buisson = new ImageIcon("Buisson.png");
		
		Dimension ecran = Toolkit.getDefaultToolkit().getScreenSize();

		 h = ecran.getSize().height*(9.0/10.0)/(1000);
		
		//Niveau 1
		ArrayList<Obstacle> OBSTACLES1= new ArrayList<Obstacle>();
		ArrayList<ObstacleBouge> OBSTACLESBOUGE1 = new ArrayList<ObstacleBouge>();
	
		ArrayList<Pendule> PENDULES1 = new ArrayList<Pendule>();

		Boule BOULE1=new Boule((int)(390*h),(int)(150*h),(int)(20*h),PENDULES1);
		PENDULES1.add(new PenduleF(0*h,(int)(390*h),(int)(95*h),BOULE1,1.8));
		
		ArrayList<Etoile> LISTEETOILES1 = new ArrayList<Etoile>();
		LISTEETOILES1.add(new Etoile((int)(390*h), (int)(209*h),(int)(40*h),(int)(25*h)));
		LISTEETOILES1.add(new Etoile((int)(390*h), (int)(354*h),(int)(40*h),(int)(25*h)));
		LISTEETOILES1.add(new Etoile((int)(390*h),(int)(522*h),(int)(40*h),(int)(25*h)));
				
		Arrive ARRIVE1 = new Arrive((int)(280*h),(int)(650*h),(int)(120*h),(int)(400*h));
		
		
		// Niveau 2
		ArrayList<Obstacle> OBSTACLES2= new ArrayList<Obstacle>();
		ArrayList<ObstacleBouge> OBSTACLESBOUGE2 = new ArrayList<ObstacleBouge>();

		ArrayList<Pendule> PENDULES2 = new ArrayList<Pendule>();
		Boule BOULE2=new Boule(c(658),(int)(421*h),(int)(20*h),PENDULES2);
		PENDULES2.add(new PenduleF(0,(int)(377*h),(int)(164*h),BOULE2,1.8));
		PENDULES2.add(new PenduleF(0,(int)(h*718),(int)(h*349),BOULE2,1.8));
				
		ArrayList<Etoile> LISTEETOILES2 = new ArrayList<Etoile>();
		LISTEETOILES2.add(new Etoile((int)(h*276), (int)(h*515),(int)(h*40), (int)(h*25)));
		LISTEETOILES2.add(new Etoile((int)(h*455), (int)(h*517), (int)h*40, (int)(h*25)));
		LISTEETOILES2.add(new Etoile((int)(h*604), (int)(437*h), (int)(h*40), (int)(h*25)));
				
		Arrive ARRIVE2 = new Arrive((int)(30*h),c(630),c(120),c(400));
		
		// Niveau 3
		ArrayList<Obstacle> OBSTACLES3= new ArrayList<Obstacle>();
		OBSTACLES3.add(new Obstacle(c(635),c(190),c(200),c(400),0,Rocher,0.8));
		ArrayList<ObstacleBouge> OBSTACLESBOUGE3 = new ArrayList<ObstacleBouge>();

		ArrayList<Pendule> PENDULES3 = new ArrayList<Pendule>();
		
		Boule BOULE3=new Boule(c(620),c(222),c(20),PENDULES3);
		PENDULES3.add(new PenduleF(0,c(385),c(76),BOULE3,1.8));
		PENDULES3.add(new PenduleF(0,c(671),c(131),BOULE3,1.8));
		
				
		ArrayList<Etoile> LISTEETOILES3 = new ArrayList<Etoile>();
		LISTEETOILES3.add(new Etoile(c(521),c(313), c(40), c(25)));
		LISTEETOILES3.add(new Etoile(c(351),c(362), c(40), c(25)));
		LISTEETOILES3.add(new Etoile(c(164),c(271), c(40), c(25)));
				
		Arrive ARRIVE3 = new Arrive(c(405),c(490),c(120),c(400));
		
		// Niveau 4
		ArrayList<Obstacle> OBSTACLES4= new ArrayList<Obstacle>();
		OBSTACLES4.add(new Obstacle(c(31),c(393),c(340),c(50),0,Plateforme,0.8));
		OBSTACLES4.add(new Obstacle(c(435),c(393),c(300),c(50),0,Plateforme,0.8));
		
		ArrayList<ObstacleBouge> OBSTACLESBOUGE4 = new ArrayList<ObstacleBouge>();

		ArrayList<Pendule> PENDULES4 = new ArrayList<Pendule>();
		Boule BOULE4=new Boule(c(454),c(193),c(20),PENDULES4);
		PENDULES4.add(new PenduleF(0,c(302),c(104),BOULE4,1.8));
		PENDULES4.add(new PenduleF(0,c(492),c(107),BOULE4,1.8));
		
		ArrayList<Etoile> LISTEETOILES4 = new ArrayList<Etoile>();
		LISTEETOILES4.add(new Etoile(c(183), c(213), c(40), c(25)));
		LISTEETOILES4.add(new Etoile(c(305), c(262), c(40), c(25)));
		LISTEETOILES4.add(new Etoile(c(399), c(384), c(40), c(25)));
				
		Arrive ARRIVE4 = new Arrive(c(280),c(530),c(120),c(400));
		
		// Niveau 5
		ArrayList<Obstacle> OBSTACLES5= new ArrayList<Obstacle>();
		OBSTACLES5.add(new Obstacle(c(664),c(63),c(150),c(400),0,Rocher,0.8));
			
		ArrayList<ObstacleBouge> OBSTACLESBOUGE5 = new ArrayList<ObstacleBouge>();
		OBSTACLESBOUGE5.add(new ObstacleBouge(c(40),c(357),c(400),c(60), 0, Plateforme, 0.8, c(40),c(200),0,0,1.5,0));
		OBSTACLESBOUGE5.add(new ObstacleBouge(c(254),c(457),c(400),c(60), 0, Plateforme, 0.8, c(254),c(400),0,0,1.5,0));
		

		ArrayList<Pendule> PENDULES5 = new ArrayList<Pendule>();
		Boule BOULE5=new Boule(c(487),c(150),c(20),PENDULES5);
		PENDULES5.add(new PenduleF(0,c(240),c(73),BOULE5,1.8));
		PENDULES5.add(new PenduleF(0,c(513),c(93),BOULE5,1.8));
		
		ArrayList<Etoile> LISTEETOILES5 = new ArrayList<Etoile>();
		LISTEETOILES5.add(new Etoile(c(123), c(304), c(40), c(25)));
		LISTEETOILES5.add(new Etoile(c(625), c(402), c(40), c(25)));
		LISTEETOILES5.add(new Etoile(c(315), c(617), c(40), c(25)));
				
		Arrive ARRIVE5= new Arrive(c(200),c(695),c(120),c(400));
	
		//Niveau6 
		
		ArrayList<Obstacle> OBSTACLES6= new ArrayList<Obstacle>();
		OBSTACLES6.add(new Obstacle(c(500),c(540),c(100),c(100),0,Buisson,1.3));
		OBSTACLES6.add(new Obstacle(c(635),c(306),c(40),c(310),0,Rocher,0.9));

		ArrayList<Pendule> PENDULES6 = new ArrayList<Pendule>();

		Boule BOULE6=new Boule(c(240),c(290),c(20),PENDULES6);
		
		PENDULES6.add(new PenduleF(0,c(50),c(80),BOULE6,1.8));
		PENDULES6.add(new PenduleF(0,c(400),c(80),BOULE6,1.8));
		
		ArrayList<Etoile> LISTEETOILES6 = new ArrayList<Etoile>();
		LISTEETOILES6.add( new Etoile(c(551), c(470), c(40), c(25)));
		LISTEETOILES6.add( new Etoile(c(551), c(298), c(40), c(25)));
		LISTEETOILES6.add( new Etoile(c(675), c(220), c(40), c(25)));
				
		Arrive ARRIVE6 = new Arrive(c(690),c(440),c(180),c(400));
		
		ArrayList<ObstacleBouge> OBSTACLESBOUGE6 = new ArrayList<ObstacleBouge>();
		
		int NUM6 = 6;
		
		//Niveau 7
		
		ArrayList<Obstacle> OBSTACLES7= new ArrayList<Obstacle>();

		ArrayList<Pendule> PENDULES7 = new ArrayList<Pendule>();
		
		ArrayList<PenduleSP> PENDULESSP7 = new ArrayList<PenduleSP>();

		Boule BOULE7=new Boule(c(171),c(284),c(20),PENDULES7);
		
		PENDULES7.add(new PenduleF(0,c(90),c(80),BOULE7,1.8));
		PENDULES7.add(new PenduleF(0,c(217),c(76),BOULE7,1.8));
		
		PENDULESSP7.add(new PenduleSP(0,c(215),c(400),BOULE7,1.2,c(120)));
		PENDULESSP7.add(new PenduleSP(0,c(415),c(450),BOULE7,1.2,c(120)));
		PENDULESSP7.add(new PenduleSP(0,c(615),c(500),BOULE7,1.2,c(120)));
		
		ArrayList<Etoile> LISTEETOILES7 = new ArrayList<Etoile>();
		LISTEETOILES7.add( new Etoile(c(277), c(505), c(40), c(25)));
		LISTEETOILES7.add( new Etoile(c(489), c(564), c(40), c(25)));
		LISTEETOILES7.add( new Etoile(c(695), c(610), c(40), c(25)));
				
		Arrive ARRIVE7 = new Arrive(c(710),c(640),c(120),c(400));
		
		ArrayList<ObstacleBouge> OBSTACLESBOUGE7 = new ArrayList<ObstacleBouge>();
		
		
		//Niveau 8
		
		ArrayList<Obstacle> OBSTACLES8= new ArrayList<Obstacle>();
		
		OBSTACLES8.add(new Obstacle(0,c(611),c(700),c(100),0,Plateforme,0.8));
		

		ArrayList<Pendule> PENDULES8 = new ArrayList<Pendule>();
		
		ArrayList<PenduleSP> PENDULESSP8 = new ArrayList<PenduleSP>();

		Boule BOULE8=new Boule(c(171),c(284),c(20),PENDULES8);
		
		PENDULES8.add(new PenduleF(0,c(90),c(80),BOULE8,1.8));
		PENDULES8.add(new PenduleF(0,c(400),c(76),BOULE8,1.8));
		
		PenduleSP P81 = new PenduleSP(0,c(758),c(527),BOULE8,1.2,c(120));
		PENDULESSP8.add(P81);
		PenduleSP P82 = new PenduleSP(0,c(400),c(750),BOULE8,1.2,c(120));
		PENDULESSP8.add(P82);
		
		ArrayList<Etoile> LISTEETOILES8 = new ArrayList<Etoile>();
		LISTEETOILES8.add( new Etoile(c(754), c(424), c(40), c(25)));
		LISTEETOILES8.add( new Etoile(c(900), c(850), c(40), c(25)));
		LISTEETOILES8.add( new Etoile(c(300), c(850), c(40), c(25)));
				
		Arrive ARRIVE8 = new Arrive(c(10),c(720),c(120),c(400));
		
		ArrayList<ObstacleBouge> OBSTACLESBOUGE8 = new ArrayList<ObstacleBouge>();
		
		ArrayList<Curseur> curseurs8 =new ArrayList<Curseur>();
		curseurs8.add(new Curseur(c(758),c(758),c(300),c(800),P81));
		curseurs8.add(new Curseur(c(10),c(900),c(750),c(750),P82));
		
		
		
		
		//Niveau 9
		
		ArrayList<Obstacle> OBSTACLES9= new ArrayList<Obstacle>();
		
		OBSTACLES9.add(new Obstacle(c(240),c(820)+100,c(150),c(100),0,Buisson,1.2));
		OBSTACLES9.add(new Obstacle(c(550),c(320)+100,c(240),c(40),0,Plateforme,0.8));
	
		ArrayList<ObstacleBouge> OBSTACLESBOUGE9 = new ArrayList<ObstacleBouge>();

		ArrayList<Pendule> PENDULES9 = new ArrayList<Pendule>();
		
		ArrayList<PenduleSP> PENDULESSP9 = new ArrayList<PenduleSP>();

		Boule BOULE9=new Boule(c(75),c(625)+100,c(20),PENDULES9);
		
		PENDULES9.add(new PenduleF(0,c(20),c(470)+100,BOULE9,1.8));
		PENDULES9.add(new PenduleF(0,c(200),c(470)+100,BOULE9,1.8));
		PENDULES9.add(new PenduleF(0,c(155),c(400)+100,BOULE9,1.8));
		
		PenduleSP P91 = new PenduleSP(0,c(420),c(630)+100,BOULE9,1.2,c(30));
		PENDULESSP9.add(P91);
		PenduleSP P92 = new PenduleSP(0,c(500),c(630)+100,BOULE9,1.2,c(30));
		PENDULESSP9.add(P92);
		PenduleSP P93 = new PenduleSP(0,c(490),c(400)+100,BOULE9,1.2,c(110));
		PENDULESSP9.add(P93);
		PenduleSP P94 = new PenduleSP(0,c(550),c(150)+100,BOULE9,1.2,c(30));
		PENDULESSP9.add(P94);
		PenduleSP P95 = new PenduleSP(0,c(670),c(300)+100,BOULE9,1.2,c(30));
		PENDULESSP9.add(P95);
		PenduleSP P96 = new PenduleSP(0,c(300),c(350)+100,BOULE9,1.2,c(30));
		PENDULESSP9.add(P96);
		PenduleSP P97 = new PenduleSP(0,c(230),c(600)+100,BOULE9,1.2,c(40));
		PENDULESSP9.add(P97);
		PenduleSP P98 = new PenduleSP(0,c(500),c(150)+100,BOULE9,1.2,c(30));
		PENDULESSP9.add(P98);
		
		ArrayList<Etoile> LISTEETOILES9 = new ArrayList<Etoile>();
		LISTEETOILES9.add( new Etoile(c(300), c(560)+100, c(40), c(25)));
		LISTEETOILES9.add( new Etoile(c(500), c(250)+100, c(40), c(25)));
		LISTEETOILES9.add( new Etoile(c(730), c(150)+100, c(40), c(25)));
				
		Arrive ARRIVE9 = new Arrive(c(160)-50,0,c(120),c(400));
		
		
		ArrayList<Curseur> curseurs9 =new ArrayList<Curseur>();
		
		curseurs9.add(new Curseur(c(390),c(600),c(630)+100,c(630)+100,P91));
		curseurs9.add(new Curseur(c(500),c(500),c(350)+100,c(630)+100,P92));
		curseurs9.add(new Curseur(c(490),c(700),c(400)+100,c(400)+100,P93));
		curseurs9.add(new Curseur(c(450),c(750),c(150)+100,c(150)+100,P94));
		curseurs9.add(new Curseur(c(670),c(670),c(100)+100,c(300)+100,P95));
		curseurs9.add(new Curseur(c(200),c(500),c(350)+100,c(350)+100,P96));
		curseurs9.add(new Curseur(c(230),c(330),c(600)+100,c(600)+100,P97));
		curseurs9.add(new Curseur(c(500),c(500),c(150)+100,c(350)+100,P98));
		
		
		ParametresNiveau ParametresNiveau1 = new ParametresNiveau(PENDULES1, BOULE1, ARRIVE1, LISTEETOILES1, OBSTACLES1,OBSTACLESBOUGE1,1);
		ParametresNiveau ParametresNiveau2 = new ParametresNiveau(PENDULES2, BOULE2, ARRIVE2, LISTEETOILES2, OBSTACLES2,OBSTACLESBOUGE2,2);
		ParametresNiveau ParametresNiveau3 = new ParametresNiveau(PENDULES3, BOULE3, ARRIVE3, LISTEETOILES3, OBSTACLES3,OBSTACLESBOUGE3,3);
		ParametresNiveau ParametresNiveau4 = new ParametresNiveau(PENDULES4, BOULE4, ARRIVE4, LISTEETOILES4, OBSTACLES4,OBSTACLESBOUGE4,4);
		ParametresNiveau ParametresNiveau5 = new ParametresNiveau(PENDULES5, BOULE5, ARRIVE5, LISTEETOILES5, OBSTACLES5,OBSTACLESBOUGE5,5);
		ParametresNiveau ParametresNiveau6 = new ParametresNiveau(PENDULES6, BOULE6, ARRIVE6, LISTEETOILES6, OBSTACLES6,OBSTACLESBOUGE6,6);
		ParametresNiveau ParametresNiveau7 = new ParametresNiveau(PENDULES7, BOULE7, ARRIVE7, LISTEETOILES7, OBSTACLES7,OBSTACLESBOUGE6,7,PENDULESSP7, null);
		ParametresNiveau ParametresNiveau8 = new ParametresNiveau(PENDULES8, BOULE8, ARRIVE8, LISTEETOILES8, OBSTACLES8,OBSTACLESBOUGE8,8,PENDULESSP8, curseurs8);
		ParametresNiveau ParametresNiveau9 = new ParametresNiveau(PENDULES9, BOULE9, ARRIVE9, LISTEETOILES9, OBSTACLES9,OBSTACLESBOUGE9,9,PENDULESSP9, curseurs9);
		
		ListeParametres = new ArrayList <ParametresNiveau>();
		ListeParametres.add(ParametresNiveau1);
		ListeParametres.add(ParametresNiveau2);
		ListeParametres.add(ParametresNiveau3);
		ListeParametres.add(ParametresNiveau4);
		ListeParametres.add(ParametresNiveau5);
		ListeParametres.add(ParametresNiveau6);
		ListeParametres.add(ParametresNiveau7);
		ListeParametres.add(ParametresNiveau8);		
		ListeParametres.add(ParametresNiveau9);
		
	}

	public int c(int x){

		return (int)(x*h);
	}
}
