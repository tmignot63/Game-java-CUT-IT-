import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;
import java.awt.Graphics;
import java.util.ArrayList; 

public class Pendule extends Objet{
   
	double teta;//angle par rapport a la verticale
	double teta2;//vitesse angulaire
	double teta3;//acceleration angulaire
	double l;//longueur du pendule

	Boule boule;

	double teta_a;
	double a=0;
	
	public Pendule(double teta2_ini,double x_ini, double y_ini,Boule boule1){

		super(x_ini,y_ini);
		boule=boule1;
		
		teta2=teta2_ini;
		teta3=0 ;
		l=Math.sqrt((x_ini-boule.x)*(x_ini-boule.x)+(y_ini-boule.y)*(y_ini-boule.y));

		x=x_ini;
		y=y_ini;

		teta=Math.atan((boule.x-x)/(boule.y-y));

		if(boule.y-y<0){teta+=Math.PI;}
		
	}

	public void simulate(){

		//calcul pour faire osciller le pendule
		teta_a=teta;
		teta3 = - 1.0* g* Math.sin(teta)/l+a/l ;
		teta2 += teta3;
		teta += teta2 ;

	}


	public void miseajour1(){
		// mise a jour des parametres du pendule avec le curseur

		l=Math.sqrt((x-boule.x)*(x-boule.x)+(y-boule.y)*(y-boule.y));
		teta=Math.atan((boule.x-x)/(boule.y-y));

		if(boule.y-y<0){teta+=Math.PI;}
	}

	
	public double getY(){
		return (y+l*Math.cos(teta));

	}

	public double getX(){
		return (x+l*Math.sin(teta));

	}

	public double vitesse_x(){
		//vitesse fournie suivant x a la boule au moment ou on coupe la corde

		if(x>boule.x){

		return -l*teta2*Math.sin(Math.atan((boule.y-y)/(boule.x-x)));
		}

		else{

		return l*teta2*Math.sin(Math.atan((boule.y-y)/(boule.x-x)));

		}

	}

	public double vitesse_y(){
		// meme chose suivant y

		if(x>boule.x){

			return l*teta2*Math.cos(Math.atan((boule.y-y)/(boule.x-x)));

	}

		else{

		
			return -l*teta2*Math.cos(Math.atan((boule.y-y)/(boule.x-x)));
		}
		
	}

	public void dessine(Graphics g){

		//dessin du pendule

		double x1=x;
		double y1=y;
		double x2=getX();
		double y2=getY();
		
		g.setColor(Color.RED);
		g.fillOval((int)x1-7,(int)y1-7,15,15);
		g.setColor(Color.BLACK);
		g.drawLine((int)x1,(int)y1,(int)x2,(int)y2);

		boule.x_a=x;
		boule.y_a=y;

		boule.x=x2;
		boule.y=y2;

	}
}