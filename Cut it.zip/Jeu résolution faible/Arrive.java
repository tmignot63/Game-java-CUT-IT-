public class Arrive{
	//caracteristiques de l'arrive
	int x;
	int y;
	//rayon de detection pour l'animation du OmNom
	int l;
	int d;
	
	public Arrive(int X, int Y, int L, int D){
		x = X;
		y = Y;
		l = L;
		d = D;
	}
}
