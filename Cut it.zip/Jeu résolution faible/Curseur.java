
import java.awt.Graphics;
import java.awt.Color;

public class Curseur {
	//pendule rattachee au curseur
	Pendule pendule;
	//deplacements min et max du curseur
	double xmin;
	double xmax;
	double ymax;
	double ymin;
	double ancienx;
	double nouveaux;
	double ancieny;
	double nouveauy;

public Curseur(double xmin, double xmax, double ymin, double ymax,Pendule pendule){

	//caracteristiques du curseur 

	//deplacements max et min du curseur suivant x et y
	this.xmin=xmin;
	this.xmax=xmax;
	this.ymin=ymin;
	this.ymax=ymax;
	//pendule associe au curseur
	this.pendule=pendule;
	//anciennes coordonnes
	ancienx=pendule.x;
	ancieny=pendule.y;

}

public void deplacer(double x1, double y1,boolean cdt){
	//deplacer le pendule en fonction des coordonnes de la souris

	if(ymin==ymax){

		if(x1<=xmax && x1>=xmin){
			Boule b=pendule.boule;
			pendule.x=x1;
			ancienx=nouveaux;
			nouveaux=x1;

				if(cdt==false){
				pendule.miseajour1();
			}

		}
		else{
			if(x1<xmin){
				Boule b=pendule.boule;
			pendule.x=xmin;
			ancienx=nouveaux;
			nouveaux=xmin;

		}
			else{
				Boule b=pendule.boule;
				pendule.x=xmax;
				ancienx=nouveaux;
				nouveaux=xmax;

			}

		}
	}

	else{

		if(y1<=ymax && y1>=ymin){
			Boule b=pendule.boule;
			pendule.y=y1;
			ancieny=nouveauy;
			nouveauy=y1;
				if(cdt==false){
				
				pendule.miseajour1();
				}

			}

			else{
				if(y1<ymin){
					Boule b=pendule.boule;
				pendule.y=ymin;
				ancieny=nouveauy;
				nouveauy=ymin;
				}
		else{
			Boule b=pendule.boule;
				pendule.y=ymax;
				ancieny=nouveauy;
				nouveauy=ymax;
	
			}
		}


		}
	}

public void dessine(Graphics g){
	g.setColor(Color.blue);

	if(ymin==ymax){

		g.drawRect((int)xmin-7,(int)ymin-7,(int)xmax-(int)xmin+14,14);
			
		}
		else{
		g.drawRect((int)xmin-7,(int)ymin-7,14,(int)ymax-(int)ymin+14);

		}

	}
}