import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList; 
import java.util.ArrayList; 
import java.awt.Font;

public class FenetreMenu extends JFrame implements ActionListener {
	
	private LinkedList<JButton> maListeNiveau;
	private JButton Niveau1; 
	private JButton Niveau2; 
	private JButton Niveau3; 
	private JButton Niveau4; 
	private JButton Niveau5; 
	private JButton Niveau6; 
	private JButton Niveau7; 
	private JButton Niveau8; 
	private JButton Niveau9; 

	
	JPanel Panel;
	JLabel Fond;

	JPanel Pannel;
	
	JLabel nEtoiles;
	int nbEtoiles;
	JLabel Star;

	Parametres ParametresNiveaux = new Parametres();
	ArrayList <ObstacleBouge> obstaclesbouge;
	
	public FenetreMenu(){
		this.setTitle("CUT IT");
		this.setSize(564,800);
		this.setLocation(100,100);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel myLabel = new JLabel ("Cut It"); 
		myLabel.setBounds(150,5,500,200);
		myLabel.setForeground(Color.black);
		Font myFont = new Font ("Arial",Font.BOLD,100);
		Font myFont2 = new Font ("Arial",Font.BOLD,15);
		Font myFont3 = new Font ("Arial",Font.BOLD,60);
		myLabel.setFont(myFont); 
		
		maListeNiveau = new LinkedList<JButton>();

		Niveau1 = new JButton("1");
		Niveau2 = new JButton("2");
		Niveau3 = new JButton("3");
		Niveau4 = new JButton("4");
		Niveau5 = new JButton("5");
		Niveau6 = new JButton("6");
		Niveau7 = new JButton("7");
		Niveau8 = new JButton("8");
		Niveau9 = new JButton("9");
		
	

		
		maListeNiveau.add(Niveau1); 
		maListeNiveau.add(Niveau2); 
		maListeNiveau.add(Niveau3);
		maListeNiveau.add(Niveau4); 
		maListeNiveau.add(Niveau5); 
		maListeNiveau.add(Niveau6);
		maListeNiveau.add(Niveau7); 
		maListeNiveau.add(Niveau8); 
		maListeNiveau.add(Niveau9);
	
	

		
		 Pannel = new JPanel();
		Pannel.setBounds(0,0,564,600);
		Pannel.setLayout(null);
		Pannel.add(myLabel);
		
		
		
		int a = 100; int b = 160; int i = 1;
		for(JButton Niveau : maListeNiveau){
			Niveau.setBounds(a,b,100,100);
			a += 125;
			if(i%3==0){
				b += 125;
				a = 100;
			}
			Niveau.setBackground(new Color(50,140,60));
			Niveau.setForeground(Color.black);
			Niveau.addActionListener(this);
			Niveau.setFont(myFont3);
			Pannel.add(Niveau);

			i++;
		}
		
		nbEtoiles = 0;
		nEtoiles = new JLabel();
		nEtoiles.setText("Etoiles : "+ nbEtoiles +" /27");
		nEtoiles.setBounds(280,10,120,20);
		nEtoiles.setForeground(Color.black);
		
		nEtoiles.setFont(myFont2);
		nEtoiles.setLayout(null);
		this.add(nEtoiles);
		Star = new JLabel(new ImageIcon("Star4.jpg"));
		Star.setBounds(240,10,24,30);
		Pannel.add(Star);

		Fond = new JLabel(new ImageIcon("FondMenu.jpg"));
		Fond.setBounds(0,0,564,846);
		Pannel.add(Fond);
		
		this.add(Pannel);
		
		this.setVisible(true);
			
	}
	
	public void actionPerformed (ActionEvent e){

			if (e.getSource()== Niveau1){FenetreNiveau FenetreNiveau = new FenetreNiveau(ParametresNiveaux.ListeParametres.get(0)); this.dispose();}
			if (e.getSource()== Niveau2){FenetreNiveau FenetreNiveau = new FenetreNiveau(ParametresNiveaux.ListeParametres.get(1)); this.dispose();}
			if (e.getSource()== Niveau3){FenetreNiveau FenetreNiveau = new FenetreNiveau(ParametresNiveaux.ListeParametres.get(2)); this.dispose();}
			if (e.getSource()== Niveau4){FenetreNiveau FenetreNiveau = new FenetreNiveau(ParametresNiveaux.ListeParametres.get(3)); this.dispose();}
			if (e.getSource()== Niveau5){FenetreNiveau FenetreNiveau = new FenetreNiveau(ParametresNiveaux.ListeParametres.get(4)); this.dispose();}
			if (e.getSource()== Niveau6){FenetreNiveau FenetreNiveau = new FenetreNiveau(ParametresNiveaux.ListeParametres.get(5)); this.dispose();}
			if (e.getSource()== Niveau7){FenetreNiveau FenetreNiveau = new FenetreNiveau(ParametresNiveaux.ListeParametres.get(6)); this.dispose();}
			if (e.getSource()== Niveau8){FenetreNiveau FenetreNiveau = new FenetreNiveau(ParametresNiveaux.ListeParametres.get(7)); this.dispose();}
			if (e.getSource()== Niveau9){FenetreNiveau FenetreNiveau = new FenetreNiveau(ParametresNiveaux.ListeParametres.get(8)); this.dispose();} 
			
	}

}
