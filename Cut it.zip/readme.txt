Nous avons fait deux versions en fonction de la r�solution de l'�cran car nous nous sommes aper�u que la version
"r�solution �lev�e" ne s'affichait correctement que pour des �crans avec une r�solution sup�rieure ou �gale � 1920*1080.

La version "r�solution faible" est un peu moins compl�te que l'autre (moins de niveaux) mais permettra tout de m�me un 
affichage correct si votre r�solution est inf�rieure � 1920*1080.

Pour lancer le jeu : compiler, ex�cuter la classe main1

Raccourcis clavier pendant le jeu : 
 - Espace : recommencer le niveau
 - Entrer : fermer la fen�tre du niveau 

Bugs rencontr�s : l�gers bugs d'affichage possibles lors d'une collision entre un obstacle et une boule accrcoch�e � un curseur
si la vitesse du curseur est trop importante.
