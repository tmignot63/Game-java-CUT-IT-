import java.util.ArrayList;

public class ParametresNiveau{
	ArrayList <Pendule> pendules;
	ArrayList <PenduleSP> pendulesSP;
	Boule boule;
	Arrive arrive;
	ArrayList<Etoile> ListeEtoiles;
	ArrayList <Obstacle> obstacles;
	ArrayList <ObstacleBouge> obstaclesB;
	ArrayList <Curseur> curseurs;
	int numero;


	
	public ParametresNiveau(ArrayList<Pendule> pendulest, Boule boulet, Arrive arrivet, ArrayList<Etoile> ListeEtoilest, ArrayList<Obstacle> obstaclest,ArrayList<ObstacleBouge> obstaclesB, int numt,ArrayList<PenduleSP> pendulesSP,ArrayList<Curseur> curseurs){
		this.pendules = pendulest;
		this.boule = boulet;
		this.arrive = arrivet;
		this.ListeEtoiles = ListeEtoilest;
		this.obstacles = obstaclest; 
		this.obstaclesB = obstaclesB; 
		this.numero = numt;
		
		if(curseurs!=null){
			this.curseurs=curseurs;
		} else {
			this.curseurs = new ArrayList<Curseur> ();
		}
		
		if(pendulesSP!=null){
			this.pendulesSP=pendulesSP;
			
		} else {
			this.pendulesSP= new ArrayList<PenduleSP> ();
		}

	


		

		
			
			


		
		


		
		
	}

	public ParametresNiveau(ArrayList<Pendule> pendulest, Boule boulet, Arrive arrivet, ArrayList<Etoile> ListeEtoilest, ArrayList<Obstacle> obstaclest,ArrayList<ObstacleBouge> obstaclesB, int numt){
		this.pendules = pendulest;
		this.boule = boulet;
		this.arrive = arrivet;
		this.ListeEtoiles = ListeEtoilest;
		this.obstacles = obstaclest; 
		this.obstaclesB = obstaclesB; 
		this.numero = numt;
		this.pendulesSP=new ArrayList<PenduleSP>();
		this.curseurs=new ArrayList<Curseur>();
	}

	





}
