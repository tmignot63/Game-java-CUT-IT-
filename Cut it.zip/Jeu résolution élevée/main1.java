import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class main1 extends JFrame implements ActionListener {
	//main qui permet de lancer le programme et de lancer la première fenetre
	
	private JButton Play; 
	private JButton Help;
	JPanel Panel;
	JLabel Fond;

	public main1 (){
		
		this.setTitle("CUT IT");
		this.setSize(720,405);
		this.setLocation(300,300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		
		Fond = new JLabel(new ImageIcon("FondMain.jpg"));
		Fond.setBounds(0,0,720,405);
		
		Panel = new JPanel();
		Panel.setBounds(0,0,720,405);
		Panel.setLayout(null);
		
		Font myFont = new Font ("Arial",Font.BOLD,20);
		
		Play = new JButton("Jouer");
		Play.setBounds(50,45,150,100);
		Play.setBackground(Color.darkGray);
		Play.setForeground(Color.white);
		Play.setFont(myFont);
		Play.addActionListener(this);
		
		Help = new JButton("Aide");
		Help.setBounds(550,250,100,100);
		Help.setBackground(Color.darkGray);
		Help.setForeground(Color.white);
		Help.setFont(myFont);
		Help.addActionListener(this);
		
		Panel.add(Play);
		Panel.add(Help);
		Panel.add(Fond);
		this.add(Panel);
		this.setVisible(true);
		
	}
	
	
	
	public static void main(String args[]){
		main1 Main = new main1();
	}
		
	public void actionPerformed (ActionEvent e){
		
		if(e.getSource() == Play){
			FenetreMenu menu=new FenetreMenu();
		}
		
		if(e.getSource() == Help){
			FenetreAide aide = new FenetreAide();
		}
	
	}
	
	
}
