import java.util.ArrayList; 
import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import java.awt.Graphics;
import javax.swing.Timer;

public class ObstacleBouge extends Obstacle{
	double xmin;
	double xmax;
	double ymax;
	double ymin;
	double vx;
	double vy;

	boolean deplacementx;
	
	public ObstacleBouge(int x,int y, int tx, int ty,int teta,ImageIcon image,double choc, double xmin,double xmax,double ymin,double ymax,double vx,double vy){
		
		super(x,y,tx,ty,teta,image,choc);
		this.xmin=xmin;
		this.xmax=xmax;
		this.ymax=ymax;
		this.ymin=ymin;
		this.vy=vy;
		this.vx=vx;

		// verification pour connaitre si le deplacement de l'obstacle est vertical ou horizontal
		if(ymin==ymax){
			deplacementx=true;

		}
		else{
			deplacementx=false;
		}

	}

	public void bouger(){

		// bouger l'obstacle dans la direction souhaitee a une vitesse constante

		if(deplacementx==true){

			if(x<=xmax && vx>0){

				x=x+vx;
				
			}

			if(x>=xmin && vx<0){
					x=x+vx;
					
				}
			

			if(x>xmax){

				vx*=-1;
				x=xmax;
				
			}

			if(x<xmin){

				vx*=-1;
				x=xmin;
				
			}

		}

		else{

			if(y<=ymax && vy>0){

				y=y+vy;
			}

			if(y>=ymin && vy<0){
				y=y+vy;
			}
			
			if(y>ymax){

				vy*=-1;
				y=ymax;
			}

			if(y<ymin){

				vy*=-1;
				y=ymin;
			}

		}
	}
	
}