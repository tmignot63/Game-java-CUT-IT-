import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;
import java.awt.Graphics;
import javax.swing.Timer;
import java.util.ArrayList; 
import java.awt.Font;

public  class FenetreResultat extends JFrame implements ActionListener{

	JButton Quitter;
	JButton Recommencer;
	JButton NiveauSuivant;
	JLabel nEtoiles;
	int N;
	FenetreNiveau FenetreNiveau1 ;
	JLabel Fond;
	ArrayList <JLabel> Etoiles;

	FenetreMenu menu;
	Parametres ParametresNiveaux = new Parametres();

	public FenetreResultat(boolean R, int k, int n){
		//fenetre qui s'affiche lorsqu'on gagne ou perd
		
		this.setLocation(100,100);
		this.setSize(600, 600);
		this.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );

		JPanel PanneauResultat = new JPanel();
		PanneauResultat.setBounds(0,0,600,600);
		PanneauResultat.setLayout(null);
		PanneauResultat.setBackground(Color.white);
		
		if(R) {
			Fond = new JLabel(new ImageIcon("Fond2.png"));
		} else {
			Fond = new JLabel(new ImageIcon("Fond1.png"));
		}
		Fond.setBounds(0,0,600,600);
		
		nEtoiles = new JLabel();
		int a = 3-k;
		N = n;
		nEtoiles.setText("Etoiles : "+ a +" /3");
		nEtoiles.setBounds(0,0,400,80);
		nEtoiles.setForeground(Color.black);
		nEtoiles.setLayout(null);
		
		JLabel FondEtoiles1 = new JLabel(new ImageIcon("Star2.png"));
		FondEtoiles1.setBounds(0,75,75,75);
		JLabel FondEtoiles2 = new JLabel(new ImageIcon("Star2.png"));
		FondEtoiles2.setBounds(75,75,75,75);
		JLabel FondEtoiles3 = new JLabel(new ImageIcon("Star2.png"));
		FondEtoiles3.setBounds(150,75,75,75);
		
		Etoiles = new ArrayList <JLabel>();
		Etoiles.add(FondEtoiles1);
		Etoiles.add(FondEtoiles2);
		Etoiles.add(FondEtoiles3);
		
		Font font = new Font("Arial",Font.BOLD,50);
		Font font2 = new Font("Arial",Font.BOLD,20);
		
		nEtoiles.setFont(font);
	
		Quitter = new JButton("Quitter");
		Quitter.setBounds(0,475,200,90);
		Quitter.setBackground(Color.darkGray);
		Quitter.setForeground(Color.white);
		Quitter.addActionListener(this);
		Quitter.setFont(font2);
	
		Recommencer = new JButton("Recommencer");
		Recommencer.setBounds(200,475,200,90);
		Recommencer.setBackground(Color.darkGray);
		Recommencer.setForeground(Color.white);
		Recommencer.addActionListener(this);
		Recommencer.setFont(font2);
		
		NiveauSuivant = new JButton("NiveauSuivant");
		NiveauSuivant.setBounds(400,475,200,90);
		NiveauSuivant.setBackground(Color.darkGray);
		NiveauSuivant.setForeground(Color.white);
		NiveauSuivant.addActionListener(this);
		NiveauSuivant.setFont(font2);
	
		PanneauResultat.add(Recommencer);
		PanneauResultat.add(Quitter);
		PanneauResultat.add(NiveauSuivant);

		for(int i = 0; i<3-k; i++){
			if(R){	
				PanneauResultat.add(Etoiles.get(i));
			}
		}
		if(R){
			PanneauResultat.add(nEtoiles);
		}
		PanneauResultat.add(Fond);
		
		this.add(PanneauResultat);
		
		this.setVisible(true);
		
	}
	
		public void actionPerformed(ActionEvent e){
		
			if(e.getSource() == Quitter){

				 menu=new FenetreMenu();

				this.dispose();
			}
	
			if(e.getSource() == Recommencer){
				
				 FenetreNiveau1 = new FenetreNiveau(ParametresNiveaux.ListeParametres.get(N-1));
				
				this.dispose();
				
			}
	
			if(e.getSource() == NiveauSuivant){

				if(N<=ParametresNiveaux.ListeParametres.size()-1){

				FenetreNiveau1= new FenetreNiveau(ParametresNiveaux.ListeParametres.get(N));
				this.dispose();
				}
				else{
					
					this.dispose();

				}

			}
		}

		public void recommencer(){
			//recommencer un niveau
			
			FenetreNiveau FenetreNiveau1 = new FenetreNiveau(ParametresNiveaux.ListeParametres.get(N-1));
			this.dispose();
			
		}	
}



