import java.util.ArrayList; 
import javax.swing.*;

public class Parametres{
	ArrayList <ParametresNiveau> ListeParametres;
	
	public Parametres(){
		//initialisation de toutes les coordonnes de tous elements
		
		ImageIcon Plateforme = new ImageIcon("Plateforme.png");
		ImageIcon Rocher = new ImageIcon("Rocher.jpg");
		ImageIcon Buisson = new ImageIcon("Buisson.png");
		//Niveau 1
		ArrayList<Obstacle> OBSTACLES1= new ArrayList<Obstacle>();
		ArrayList<ObstacleBouge> OBSTACLESBOUGE1 = new ArrayList<ObstacleBouge>();
	
		ArrayList<Pendule> PENDULES1 = new ArrayList<Pendule>();

		Boule BOULE1=new Boule(390,150,20,PENDULES1);
		PENDULES1.add(new PenduleF(0,390,95,BOULE1,1.8));
		
		ArrayList<Etoile> LISTEETOILES1 = new ArrayList<Etoile>();
		LISTEETOILES1.add(new Etoile(390, 209, 40, 25));
		LISTEETOILES1.add(new Etoile(390, 354, 40, 25));
		LISTEETOILES1.add(new Etoile(390, 522, 40, 25));
				
		Arrive ARRIVE1 = new Arrive(280,650,120,400);
		
		
		// Niveau 2
		ArrayList<Obstacle> OBSTACLES2= new ArrayList<Obstacle>();
		ArrayList<ObstacleBouge> OBSTACLESBOUGE2 = new ArrayList<ObstacleBouge>();

		ArrayList<Pendule> PENDULES2 = new ArrayList<Pendule>();
		Boule BOULE2=new Boule(658,421,20,PENDULES2);
		PENDULES2.add(new PenduleF(0,377,164,BOULE2,1.8));
		PENDULES2.add(new PenduleF(0,718,349,BOULE2,1.8));
				
		ArrayList<Etoile> LISTEETOILES2 = new ArrayList<Etoile>();
		LISTEETOILES2.add(new Etoile(276, 515, 40, 25));
		LISTEETOILES2.add(new Etoile(455, 517, 40, 25));
		LISTEETOILES2.add(new Etoile(604, 437, 40, 25));
				
		Arrive ARRIVE2 = new Arrive(30,630,120,400);
		
		// Niveau 3
		ArrayList<Obstacle> OBSTACLES3= new ArrayList<Obstacle>();
		OBSTACLES3.add(new Obstacle(635,190,200,400,0,Rocher,0.8));
		ArrayList<ObstacleBouge> OBSTACLESBOUGE3 = new ArrayList<ObstacleBouge>();

		ArrayList<Pendule> PENDULES3 = new ArrayList<Pendule>();
		
		Boule BOULE3=new Boule(620,222,20,PENDULES3);
		PENDULES3.add(new PenduleF(0,385,76,BOULE3,1.8));
		PENDULES3.add(new PenduleF(0,671,131,BOULE3,1.8));
		
				
		ArrayList<Etoile> LISTEETOILES3 = new ArrayList<Etoile>();
		LISTEETOILES3.add(new Etoile(521,313, 40, 25));
		LISTEETOILES3.add(new Etoile(351,362, 40, 25));
		LISTEETOILES3.add(new Etoile(164,271, 40, 25));
				
		Arrive ARRIVE3 = new Arrive(405,490,120,400);
		
		// Niveau 4
		ArrayList<Obstacle> OBSTACLES4= new ArrayList<Obstacle>();
		OBSTACLES4.add(new Obstacle(31,393,340,50,0,Plateforme,0.8));
		OBSTACLES4.add(new Obstacle(435,393,300,50,0,Plateforme,0.8));
		
		ArrayList<ObstacleBouge> OBSTACLESBOUGE4 = new ArrayList<ObstacleBouge>();

		ArrayList<Pendule> PENDULES4 = new ArrayList<Pendule>();
		Boule BOULE4=new Boule(454,193,20,PENDULES4);
		PENDULES4.add(new PenduleF(0,302,104,BOULE4,1.8));
		PENDULES4.add(new PenduleF(0,492,107,BOULE4,1.8));
		
		ArrayList<Etoile> LISTEETOILES4 = new ArrayList<Etoile>();
		LISTEETOILES4.add(new Etoile(183, 213, 40, 25));
		LISTEETOILES4.add(new Etoile(305, 262, 40, 25));
		LISTEETOILES4.add(new Etoile(399, 384, 40, 25));
				
		Arrive ARRIVE4 = new Arrive(280,530,120,400);
		
		// Niveau 5
		ArrayList<Obstacle> OBSTACLES5= new ArrayList<Obstacle>();
		OBSTACLES5.add(new Obstacle(664,63,150,400,0,Rocher,0.8));
			
		ArrayList<ObstacleBouge> OBSTACLESBOUGE5 = new ArrayList<ObstacleBouge>();
		OBSTACLESBOUGE5.add(new ObstacleBouge(40,357,400,60, 0, Plateforme, 0.8, 40,200,0,0,1.5,0));
		OBSTACLESBOUGE5.add(new ObstacleBouge(254,457,400,60, 0, Plateforme, 0.8, 254,400,0,0,1.5,0));
		

		ArrayList<Pendule> PENDULES5 = new ArrayList<Pendule>();
		Boule BOULE5=new Boule(487,150,20,PENDULES5);
		PENDULES5.add(new PenduleF(0,240,73,BOULE5,1.8));
		PENDULES5.add(new PenduleF(0,513,93,BOULE5,1.8));
		
		ArrayList<Etoile> LISTEETOILES5 = new ArrayList<Etoile>();
		LISTEETOILES5.add(new Etoile(123, 304, 40, 25));
		LISTEETOILES5.add(new Etoile(625, 402, 40, 25));
		LISTEETOILES5.add(new Etoile(315, 617, 40, 25));
				
		Arrive ARRIVE5= new Arrive(200,695,120,400);
		
		//Niveau6 
		
		ArrayList<Obstacle> OBSTACLES6= new ArrayList<Obstacle>();
		OBSTACLES6.add(new Obstacle(500,540,100,100,0,Buisson,1.3));
		OBSTACLES6.add(new Obstacle(635,306,40,310,0,Rocher,0.9));

		ArrayList<Pendule> PENDULES6 = new ArrayList<Pendule>();

		Boule BOULE6=new Boule(240,290,20,PENDULES6);
		
		PENDULES6.add(new PenduleF(0,50,80,BOULE6,1.8));
		PENDULES6.add(new PenduleF(0,400,80,BOULE6,1.8));
		
		ArrayList<Etoile> LISTEETOILES6 = new ArrayList<Etoile>();
		LISTEETOILES6.add( new Etoile(551, 470, 40, 25));
		LISTEETOILES6.add( new Etoile(551, 298, 40, 25));
		LISTEETOILES6.add( new Etoile(675, 220, 40, 25));
				
		Arrive ARRIVE6 = new Arrive(690,440,180,400);
		
		ArrayList<ObstacleBouge> OBSTACLESBOUGE6 = new ArrayList<ObstacleBouge>();
		
		int NUM6 = 6;
		
		//Niveau 7
		
		ArrayList<Obstacle> OBSTACLES7= new ArrayList<Obstacle>();

		ArrayList<Pendule> PENDULES7 = new ArrayList<Pendule>();
		
		ArrayList<PenduleSP> PENDULESSP7 = new ArrayList<PenduleSP>();

		Boule BOULE7=new Boule(171,284,20,PENDULES7);
		
		PENDULES7.add(new PenduleF(0,90,80,BOULE7,1.8));
		PENDULES7.add(new PenduleF(0,217,76,BOULE7,1.8));
		
		PENDULESSP7.add(new PenduleSP(0,215,400,BOULE7,1.2,120));
		PENDULESSP7.add(new PenduleSP(0,415,450,BOULE7,1.2,120));
		PENDULESSP7.add(new PenduleSP(0,615,500,BOULE7,1.2,120));
		
		ArrayList<Etoile> LISTEETOILES7 = new ArrayList<Etoile>();
		LISTEETOILES7.add( new Etoile(277, 505, 40, 25));
		LISTEETOILES7.add( new Etoile(489, 564, 40, 25));
		LISTEETOILES7.add( new Etoile(695, 610, 40, 25));
				
		Arrive ARRIVE7 = new Arrive(710,640,120,400);
		
		ArrayList<ObstacleBouge> OBSTACLESBOUGE7 = new ArrayList<ObstacleBouge>();
		
		//Niveau 8
		
		ArrayList<Obstacle> OBSTACLES8= new ArrayList<Obstacle>();
		
		OBSTACLES8.add(new Obstacle(0,611,700,100,0,Plateforme,0.8));
		

		ArrayList<Pendule> PENDULES8 = new ArrayList<Pendule>();
		
		ArrayList<PenduleSP> PENDULESSP8 = new ArrayList<PenduleSP>();

		Boule BOULE8=new Boule(171,284,20,PENDULES8);
		
		PENDULES8.add(new PenduleF(0,90,80,BOULE8,1.8));
		PENDULES8.add(new PenduleF(0,400,76,BOULE8,1.8));
		
		PenduleSP P81 = new PenduleSP(0,758,527,BOULE8,1.2,120);
		PENDULESSP8.add(P81);
		PenduleSP P82 = new PenduleSP(0,400,750,BOULE8,1.2,120);
		PENDULESSP8.add(P82);
		
		ArrayList<Etoile> LISTEETOILES8 = new ArrayList<Etoile>();
		LISTEETOILES8.add( new Etoile(754, 424, 40, 25));
		LISTEETOILES8.add( new Etoile(900, 850, 40, 25));
		LISTEETOILES8.add( new Etoile(300, 850, 40, 25));
				
		Arrive ARRIVE8 = new Arrive(10,720,120,400);
		
		ArrayList<ObstacleBouge> OBSTACLESBOUGE8 = new ArrayList<ObstacleBouge>();
		
		ArrayList<Curseur> curseurs8 =new ArrayList<Curseur>();
		curseurs8.add(new Curseur(758,758,300,800,P81));
		curseurs8.add(new Curseur(10,900,750,750,P82));
		
		//Niveau 9
		
		ArrayList<Obstacle> OBSTACLES9= new ArrayList<Obstacle>();
		
		OBSTACLES9.add(new Obstacle(700,600,160,40,0,Plateforme,0.9));
		OBSTACLES9.add(new Obstacle(160,270,590,60,0,Plateforme,0.9));
		OBSTACLES9.add(new Obstacle(0,100,80,400,0,Rocher,0.9));
	
		ArrayList<ObstacleBouge> OBSTACLESBOUGE9 = new ArrayList<ObstacleBouge>();
		OBSTACLESBOUGE9.add(new ObstacleBouge(100,600,200,60, 0, Buisson, 1.5, 100,300,0,0,1.3,0));

		ArrayList<Pendule> PENDULES9 = new ArrayList<Pendule>();
		
		ArrayList<PenduleSP> PENDULESSP9 = new ArrayList<PenduleSP>();

		Boule BOULE9=new Boule(600,600,20,PENDULES9);
		
		PENDULES9.add(new PenduleF(0,850,90,BOULE9,1.8));
		PENDULES9.add(new PenduleF(0,1039,90,BOULE9,1.8));
		
		PenduleSP P91 = new PenduleSP(0,500,350,BOULE9,1.2,120);
		PENDULESSP9.add(P91);
		PenduleSP P92 = new PenduleSP(0,200,170,BOULE9,1.2,80);
		PENDULESSP9.add(P92);
		
		ArrayList<Etoile> LISTEETOILES9 = new ArrayList<Etoile>();
		LISTEETOILES9.add( new Etoile(755, 425, 40, 25));
		LISTEETOILES9.add( new Etoile(370, 470, 40, 25));
		LISTEETOILES9.add( new Etoile(200, 245, 40, 25));
				
		Arrive ARRIVE9 = new Arrive(320,60,120,400);
		
		
		ArrayList<Curseur> curseurs9 =new ArrayList<Curseur>();
		curseurs9.add(new Curseur(300,600,350,350,P91));
		curseurs9.add(new Curseur(100,400,170,170,P92));
		
		//Niveau 10
		
		ArrayList<Obstacle> OBSTACLES10= new ArrayList<Obstacle>();
		
		OBSTACLES10.add(new Obstacle(240,820,150,100,0,Buisson,1.2));
		OBSTACLES10.add(new Obstacle(520,320,300,40,0,Plateforme,0.8));
	
		ArrayList<ObstacleBouge> OBSTACLESBOUGE10 = new ArrayList<ObstacleBouge>();

		ArrayList<Pendule> PENDULES10 = new ArrayList<Pendule>();
		
		ArrayList<PenduleSP> PENDULESSP10 = new ArrayList<PenduleSP>();

		Boule BOULE10=new Boule(75,625,20,PENDULES10);
		
		PENDULES10.add(new PenduleF(0,20,470,BOULE10,1.8));
		PENDULES10.add(new PenduleF(0,200,470,BOULE10,1.8));
		PENDULES10.add(new PenduleF(0,155,400,BOULE10,1.8));
		
		PenduleSP P101 = new PenduleSP(0,420,630,BOULE10,1.2,30);
		PENDULESSP10.add(P101);
		PenduleSP P102 = new PenduleSP(0,500,630,BOULE10,1.2,30);
		PENDULESSP10.add(P102);
		PenduleSP P103 = new PenduleSP(0,490,400,BOULE10,1.2,110);
		PENDULESSP10.add(P103);
		PenduleSP P104 = new PenduleSP(0,550,150,BOULE10,1.2,30);
		PENDULESSP10.add(P104);
		PenduleSP P105 = new PenduleSP(0,670,300,BOULE10,1.2,30);
		PENDULESSP10.add(P105);
		PenduleSP P106 = new PenduleSP(0,300,350,BOULE10,1.2,30);
		PENDULESSP10.add(P106);
		PenduleSP P107 = new PenduleSP(0,230,600,BOULE10,1.2,40);
		PENDULESSP10.add(P107);
		PenduleSP P108 = new PenduleSP(0,500,150,BOULE10,1.2,30);
		PENDULESSP10.add(P108);
		
		ArrayList<Etoile> LISTEETOILES10 = new ArrayList<Etoile>();
		LISTEETOILES10.add( new Etoile(300, 560, 40, 25));
		LISTEETOILES10.add( new Etoile(500, 250, 40, 25));
		LISTEETOILES10.add( new Etoile(730, 150, 40, 25));
				
		Arrive ARRIVE10 = new Arrive(160,60,120,400);
		
		ArrayList<Curseur> curseurs10 =new ArrayList<Curseur>();
		
		curseurs10.add(new Curseur(390,600,630,630,P101));
		curseurs10.add(new Curseur(500,500,350,630,P102));
		curseurs10.add(new Curseur(490,700,400,400,P103));
		curseurs10.add(new Curseur(450,750,150,150,P104));
		curseurs10.add(new Curseur(670,670,100,300,P105));
		curseurs10.add(new Curseur(200,500,350,350,P106));
		curseurs10.add(new Curseur(230,330,600,600,P107));
		curseurs10.add(new Curseur(500,500,150,350,P108));
		
		//Niveau 11
		
		ArrayList<Obstacle> OBSTACLES11= new ArrayList<Obstacle>();
		
		OBSTACLES11.add(new Obstacle(450,480,400,60,0,Plateforme,0.8));
		OBSTACLES11.add(new Obstacle(280,110,800,60,0,Plateforme,0.8));
		OBSTACLES11.add(new Obstacle(490,250,60,230,0,Rocher,0.8));
		OBSTACLES11.add(new Obstacle(250,200,100,500,0,Rocher,0.8));
	
		ArrayList<ObstacleBouge> OBSTACLESBOUGE11 = new ArrayList<ObstacleBouge>();

		ArrayList<Pendule> PENDULES11 = new ArrayList<Pendule>();
		
		ArrayList<PenduleSP> PENDULESSP11 = new ArrayList<PenduleSP>();

		Boule BOULE11 =new Boule(115,220,20,PENDULES11);
		
		PENDULES11.add(new PenduleF(0,30,50,BOULE11,1.8));
		PENDULES11.add(new PenduleF(0,200,50,BOULE11,1.8));
		
		PenduleSP P111 = new PenduleSP(0,175,220,BOULE11,1.2,30);
		PENDULESSP11.add(P111);
		PenduleSP P112 = new PenduleSP(0,80,805,BOULE11,1.2,80);
		PENDULESSP11.add(P112);
		PenduleSP P113 = new PenduleSP(0,455,800,BOULE11,1.2,80);
		PENDULESSP11.add(P113);
		PenduleSP P114 = new PenduleSP(0,700,305,BOULE11,1.2,280);
		PENDULESSP11.add(P114);
		PenduleSP P115 = new PenduleSP(0,60,50,BOULE11,1.2,30);
		PENDULESSP11.add(P115);
		
		ArrayList<Etoile> LISTEETOILES11 = new ArrayList<Etoile>();
		LISTEETOILES11.add( new Etoile(1025, 65, 40, 25));
		LISTEETOILES11.add( new Etoile(540, 560, 40, 25));
		LISTEETOILES11.add( new Etoile(710, 560, 40, 25));
				
		Arrive ARRIVE11 = new Arrive(820,420,120,400);
		
		ArrayList<Curseur> curseurs11 =new ArrayList<Curseur>();
		curseurs11.add(new Curseur(175,175,50,400,P111));
		curseurs11.add(new Curseur(80,600,805,805,P112));
		curseurs11.add(new Curseur(455,455,300,820,P113));
		curseurs11.add(new Curseur(600,900,305,305,P114));
		curseurs11.add(new Curseur(30,1050,50,50,P115));
		
		//Niveau 12
		
		ArrayList<Obstacle> OBSTACLES12= new ArrayList<Obstacle>();
		
		OBSTACLES12.add(new Obstacle(340,620,160,40,0,Plateforme,0.8));
		OBSTACLES12.add(new Obstacle(620,630,200,40,0,Plateforme,0.8));
		OBSTACLES12.add(new Obstacle(850,630,230,40,0,Plateforme,0.8));
	
		ArrayList<ObstacleBouge> OBSTACLESBOUGE12 = new ArrayList<ObstacleBouge>();

		ArrayList<Pendule> PENDULES12 = new ArrayList<Pendule>();
		
		ArrayList<PenduleSP> PENDULESSP12 = new ArrayList<PenduleSP>();

		Boule BOULE12 =new Boule(170,220,20,PENDULES12);
		
		PENDULES12.add(new PenduleF(0,170,50,BOULE12,1.8));
		
		PenduleSP P121 = new PenduleSP(0,230,670,BOULE12,1.2,80);
		PENDULESSP12.add(P121);
		PenduleSP P122 = new PenduleSP(0,375,495,BOULE12,1.2,120);
		PENDULESSP12.add(P122);
		PenduleSP P123 = new PenduleSP(0,625,565,BOULE12,1.2,50);
		PENDULESSP12.add(P123);
		PenduleSP P124 = new PenduleSP(0,570,655,BOULE12,1.2,50);
		PENDULESSP12.add(P124);
		
		ArrayList<Etoile> LISTEETOILES12 = new ArrayList<Etoile>();
		LISTEETOILES12.add( new Etoile(306, 733, 40, 25));
		LISTEETOILES12.add( new Etoile(978, 600, 40, 25));
		LISTEETOILES12.add( new Etoile(555, 946, 40, 25));
				
		Arrive ARRIVE12 = new Arrive(790,765,120,400);
		
		
		ArrayList<Curseur> curseurs12 =new ArrayList<Curseur>();
		curseurs12.add(new Curseur(230,400,670,670,P121));
		curseurs12.add(new Curseur(375,600,495,495,P122));
		curseurs12.add(new Curseur(570,1080,565,565,P123));
		curseurs12.add(new Curseur(570,570,565,1000,P124));

		ParametresNiveau ParametresNiveau1 = new ParametresNiveau(PENDULES1, BOULE1, ARRIVE1, LISTEETOILES1, OBSTACLES1,OBSTACLESBOUGE1,1);
		ParametresNiveau ParametresNiveau2 = new ParametresNiveau(PENDULES2, BOULE2, ARRIVE2, LISTEETOILES2, OBSTACLES2,OBSTACLESBOUGE2,2);
		ParametresNiveau ParametresNiveau3 = new ParametresNiveau(PENDULES3, BOULE3, ARRIVE3, LISTEETOILES3, OBSTACLES3,OBSTACLESBOUGE3,3);
		ParametresNiveau ParametresNiveau4 = new ParametresNiveau(PENDULES4, BOULE4, ARRIVE4, LISTEETOILES4, OBSTACLES4,OBSTACLESBOUGE4,4);
		ParametresNiveau ParametresNiveau5 = new ParametresNiveau(PENDULES5, BOULE5, ARRIVE5, LISTEETOILES5, OBSTACLES5,OBSTACLESBOUGE5,5);
		ParametresNiveau ParametresNiveau6 = new ParametresNiveau(PENDULES6, BOULE6, ARRIVE6, LISTEETOILES6, OBSTACLES6,OBSTACLESBOUGE6,6);
		ParametresNiveau ParametresNiveau7 = new ParametresNiveau(PENDULES7, BOULE7, ARRIVE7, LISTEETOILES7, OBSTACLES7,OBSTACLESBOUGE6,7,PENDULESSP7, null);
		ParametresNiveau ParametresNiveau8 = new ParametresNiveau(PENDULES8, BOULE8, ARRIVE8, LISTEETOILES8, OBSTACLES8,OBSTACLESBOUGE8,8,PENDULESSP8, curseurs8);
		ParametresNiveau ParametresNiveau9 = new ParametresNiveau(PENDULES9, BOULE9, ARRIVE9, LISTEETOILES9, OBSTACLES9,OBSTACLESBOUGE9,9,PENDULESSP9, curseurs9);
		ParametresNiveau ParametresNiveau10 = new ParametresNiveau(PENDULES10, BOULE10, ARRIVE10, LISTEETOILES10, OBSTACLES10,OBSTACLESBOUGE10,10,PENDULESSP10, curseurs10);
		ParametresNiveau ParametresNiveau11 = new ParametresNiveau(PENDULES11, BOULE11, ARRIVE11, LISTEETOILES11, OBSTACLES11,OBSTACLESBOUGE11,11,PENDULESSP11, curseurs11);
		ParametresNiveau ParametresNiveau12 = new ParametresNiveau(PENDULES12, BOULE12, ARRIVE12, LISTEETOILES12, OBSTACLES12,OBSTACLESBOUGE12,12,PENDULESSP12, curseurs12);
		
		ListeParametres = new ArrayList <ParametresNiveau>();
		ListeParametres.add(ParametresNiveau1);
		ListeParametres.add(ParametresNiveau2);
		ListeParametres.add(ParametresNiveau3);
		ListeParametres.add(ParametresNiveau4);
		ListeParametres.add(ParametresNiveau5);
		ListeParametres.add(ParametresNiveau6);
		ListeParametres.add(ParametresNiveau7);
		ListeParametres.add(ParametresNiveau8);		
		ListeParametres.add(ParametresNiveau9);
		ListeParametres.add(ParametresNiveau10);
		ListeParametres.add(ParametresNiveau11);
		ListeParametres.add(ParametresNiveau12);
		
	}
}
