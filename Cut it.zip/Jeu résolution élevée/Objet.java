import java.util.ArrayList; 
import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;
import java.awt.Graphics;
import javax.swing.Timer;

public class Objet {
	
	public double x;
	public double y;
	public final int g;


  public Objet(double xo, double yo){
  x=xo;
  y=yo;
  g=1;
  
  }
	
} 
