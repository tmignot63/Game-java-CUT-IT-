public class Arrive{
	int x;
	int y;
	int l;
	int d;
	
	public Arrive(int X, int Y, int L, int D){
		x = X;
		y = Y;
		l = L;
		d = D;
	}
}
