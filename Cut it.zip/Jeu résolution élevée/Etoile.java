import javax.swing.*;
import java.awt.Color;
import java.awt.Graphics;

public class Etoile extends Objet{
	
	int taille;	
	int d;

	public Etoile(double x, double y,int t, int D){
		super(x,y);
		taille = t;
		d = D;
		
	}
	public void dessine(Graphics g){

		g.setColor(Color.yellow);
		g.fillOval((int)x-taille/2,(int)y-taille/2,taille,taille);
		
	}
	
}
