import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;
import java.awt.Graphics;
import javax.swing.Timer;
import java.util.ArrayList; 

public class PenduleF extends Pendule{
	double k;
	
	
	public PenduleF(double teta2_ini,double x_ini, double y_ini,Boule boule1, double k){

		super(teta2_ini,x_ini,y_ini,boule1);
		this.k=k;
		
	}

	public void simulate(){
		//simulation du pendule avec ax l'acceleration liee a un potentiel curseur
		teta_a=teta;
		teta3 = - 1.0* g* Math.sin(teta)/l -k*teta2/l+a/l;
		teta2 += teta3;
		teta += teta2 ;
	}

}