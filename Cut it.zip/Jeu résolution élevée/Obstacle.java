import java.util.ArrayList; 
import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import java.awt.Graphics;
import javax.swing.Timer;

public class Obstacle extends Objet{
	
	public int tx;
	public int ty;
	public int teta;
	public double choc;//coefficient qui permet d'ajuster le rebond sur obstacle
	ImageIcon icon;

	public Obstacle(int x,int y, int tx, int ty,int teta,ImageIcon image,double choc){
		
		super(x,y);
		this.teta=teta;
		this.tx=tx;
		this.ty=ty;
		this.choc=choc;
		icon = new ImageIcon(image.getImage().getScaledInstance(tx,ty,Image.SCALE_DEFAULT));
		
	}

}