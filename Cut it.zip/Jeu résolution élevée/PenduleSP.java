import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.BasicStroke;

public class PenduleSP extends PenduleF{
	double rayon_detection;
	public PenduleSP(double teta2_ini,double x_ini, double y_ini,Boule boule1, double k,double rayon){

		super(teta2_ini,x_ini,y_ini,boule1,k);
		rayon_detection=rayon;
	}

		public void dessine2(Graphics g){

		// dessiner le pendule 
		g.setColor(Color.RED);
		g.fillOval((int)x-7,(int)y-7,15,15);

		//dessiner en pointille le rayon de detection
		Graphics2D g2D = (Graphics2D) g;
		float dash1[] = {10.0f};
		BasicStroke dashed = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash1, 0.0f);
		g2D.setStroke(dashed);
		g2D.drawOval((int)x-(int)rayon_detection,(int)y-(int)rayon_detection,(int)rayon_detection*2,(int)rayon_detection*2);

	}
}